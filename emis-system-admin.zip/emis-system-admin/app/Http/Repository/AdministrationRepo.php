<?php
namespace App\Http\Repository;
interface AdministrationRepo{
    public function add_actions($param);
    public function module_management($param);
    
}